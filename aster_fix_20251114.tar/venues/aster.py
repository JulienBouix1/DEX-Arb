# venues/aster.py
from __future__ import annotations
import asyncio
import json
import os
import time
import hmac
import hashlib
import math
from typing import Dict, List, Optional, Callable, Tuple, Any
from urllib.parse import urlencode

import websockets
import aiohttp

REST_WARMUP_TIMEOUT = 5.0
WS_PING_INTERVAL = 20.0
WS_PING_TIMEOUT = 10.0
RECONNECT_BASE_DELAY = 0.8
RECONNECT_MAX_DELAY = 8.0

PAIRS_PER_WS = 8
STALE_MS_DEFAULT = 12_000
STALE_MS = int(os.getenv("ASTER_STALE_MS", str(STALE_MS_DEFAULT)))

WATCHDOG_PERIOD_S = 5.0
RESUB_BACKOFF_MS = 7_000


class _Book:
    __slots__ = ("bid", "ask", "t")

    def __init__(self, bid: float = None, ask: float = None, t: float = None):
        self.bid = bid
        self.ask = ask
        self.t = t or time.time()

    def mid(self) -> Optional[float]:
        if self.bid is None or self.ask is None:
            return None
        return (self.bid + self.ask) / 2.0


class Aster:
    def __init__(
        self,
        base_ws: str = "wss://stream.binance.com:9443/stream",
        base_rest: str = "https://api.binance.com",
        creds: dict | None = None,
    ):
        self.base_ws = base_ws.rstrip("/")
        self.base_rest = base_rest.rstrip("/")
        self.creds = creds or {}

        if ("fapi" in self.base_rest) or ("fstream" in self.base_ws):
            self._rest_ticker_path = "/fapi/v1/ticker/bookTicker"
            self._is_futures = True
        else:
            self._rest_ticker_path = "/api/v3/ticker/bookTicker"
            self._is_futures = False

        self._running = False
        self._books: Dict[str, _Book] = {}
        self._l2: Dict[str, Dict[str, List[Tuple[float, float]]]] = {}
        self._symbols: List[str] = []
        self._ws_tasks: List[asyncio.Task] = []
        self._poller_task: Optional[asyncio.Task] = None
        self._watchdog_task: Optional[asyncio.Task] = None

        self._last_update: Dict[str, float] = {}
        self._last_resub_try_ms: Dict[str, int] = {}

        self.logger: Optional[Callable[[str], None]] = None
        self._reconfigure_lock = asyncio.Lock()

        self._api_key = (self.creds.get("api_key") if isinstance(self.creds, dict) else None) or os.getenv("ASTER_API_KEY", "")
        self._api_secret = (self.creds.get("api_secret") if isinstance(self.creds, dict) else None) or os.getenv("ASTER_API_SECRET", "")

        self._exi_cache_ts = 0.0
        self._exi_cache: Dict[str, dict] = {}

    async def _get_public(self, path: str, params: Dict[str, str]) -> Optional[dict | list]:
        try:
            url = f"{self.base_rest}{path}"
            if params:
                from urllib.parse import urlencode
                url = f"{url}?{urlencode(params)}"
            timeout = aiohttp.ClientTimeout(total=8)
            async with aiohttp.ClientSession(timeout=timeout) as sess:
                async with sess.get(url) as r:
                    if r.status != 200:
                        return None
                    ct = (r.headers.get("Content-Type") or "").lower()
                    return (await r.json()) if "json" in ct else None
        except Exception:
            return None

    def _signed_headers(self) -> Dict[str, str]:
        return {"X-MBX-APIKEY": self._api_key, "User-Agent": "arb-bot/1.2"}

    def _sign_query(self, params: Dict[str, str]) -> str:
        q = urlencode(params)
        sig = hmac.new(self._api_secret.encode(), q.encode(), hashlib.sha256).hexdigest()
        return f"{q}&signature={sig}"

    async def _get(self, path: str, params: Dict[str, str]) -> Optional[dict | list]:
        try:
            url = f"{self.base_rest}{path}?{self._sign_query(params)}"
            timeout = aiohttp.ClientTimeout(total=8)
            async with aiohttp.ClientSession(timeout=timeout) as sess:
                async with sess.get(url, headers=self._signed_headers()) as r:
                    if r.status != 200:
                        return None
                    ct = (r.headers.get("Content-Type") or "").lower()
                    return (await r.json()) if "json" in ct else None
        except Exception:
            return None

    async def _post(self, path: str, params: Dict[str, str]) -> Optional[dict | list]:
        try:
            url = f"{self.base_rest}{path}?{self._sign_query(params)}"
            timeout = aiohttp.ClientTimeout(total=8)
            async with aiohttp.ClientSession(timeout=timeout) as sess:
                async with sess.post(url, headers=self._signed_headers()) as r:
                    if r.status != 200:
                        try:
                            return {"_status": r.status, "_text": await r.text()}
                        except Exception:
                            return None
                    ct = (r.headers.get("Content-Type") or "").lower()
                    return (await r.json()) if "json" in ct else None
        except Exception:
            return None

    async def _warmup_rest(self, symbols: list[str]) -> None:
        try:
            need_refresh = False
            try:
                if (time.time() - float(self._exi_cache_ts)) > 300.0:
                    need_refresh = True
            except Exception:
                need_refresh = True
            if need_refresh:
                j = await self._get_public("/fapi/v1/exchangeInfo" if self._is_futures else "/api/v3/exchangeInfo", {})
                cache = {}
                if isinstance(j, dict) and isinstance(j.get("symbols"), list):
                    for s in j["symbols"]:
                        sym = (s.get("symbol") or "").upper()
                        filters = s.get("filters") or []
                        lot = {}
                        for f in filters:
                            if f.get("filterType") == "LOT_SIZE":
                                lot["minQty"] = float(f.get("minQty", "0"))
                                lot["stepSize"] = float(f.get("stepSize", "1"))
                            if f.get("filterType") in ("NOTIONAL", "MIN_NOTIONAL"):
                                v = f.get("notional") or f.get("minNotional") or "0"
                                try:
                                    lot["minNotional"] = float(v)
                                except Exception:
                                    pass
                        if lot:
                            cache[sym] = lot
                if cache:
                    self._exi_cache = cache
                    self._exi_cache_ts = time.time()

            syms = [s.upper() for s in (symbols or []) if s]
            if not syms:
                return
            for s in syms:
                params = {"symbol": s}
                j = await self._get_public(self._rest_ticker_path, params)
                if isinstance(j, dict) and j.get("symbol"):
                    try:
                        b = float(j.get("bidPrice") or "0")
                        a = float(j.get("askPrice") or "0")
                        if b > 0 and a > 0 and a >= b:
                            self._books[s] = _Book(b, a, time.time())
                            self._last_update[s] = time.time()
                            if self.logger:
                                self.logger(f"[ASTER WARMUP] {s} bid={b:.8f} ask={a:.8f}")
                        else:
                            # invalid BBO in warmup
                            self._books.pop(s, None)
                            self._last_update.pop(s, None)
                            if self.logger:
                                reason = "non_positive" if not (b>0 and a>0) else "ask_lt_bid"
                                self.logger(f"[ASTER BLOCK] {s} reason={reason} b={b:.8f} a={a:.8f}")
                    except Exception:
                        pass
        except Exception:
            return

    async def _restart_ws(self) -> None:
        try:
            for t in list(self._ws_tasks):
                try:
                    t.cancel()
                except Exception:
                    pass
            self._ws_tasks.clear()
        except Exception:
            pass

    async def _rest_bookticker_poller(self) -> None:
        try:
            while self._running:
                syms = list(self._symbols)
                if not syms:
                    await asyncio.sleep(0.2)
                    continue
                now = time.time()
                for s in syms:
                    try:
                        j_pub = await self._get_public(self._rest_ticker_path, {"symbol": s})
                        if isinstance(j_pub, dict) and j_pub.get("symbol"):
                            b = float(j_pub.get("bidPrice") or "0")
                            a = float(j_pub.get("askPrice") or "0")
                            if b > 0 and a > 0:
                                self._books[s] = _Book(b, a, now)
                                self._last_update[s] = now
                            # Log on change and validate ask>=bid
                            if a < b:
                                self._books.pop(s, None)
                                self._last_update.pop(s, None)
                                if self.logger:
                                    self.logger(f"[ASTER BLOCK] {s} reason=ask_lt_bid b={b:.8f} a={a:.8f}")
                            else:
                                prev = self._books.get(s)
                                if self.logger and (not prev or prev.bid != b or prev.ask != a):
                                    mid = (b + a) / 2.0
                                    self.logger(f"[ASTER BBO] {s} bid={b:.8f} ask={a:.8f} mid={mid:.8f}")
                    except Exception:
                        pass
                    await asyncio.sleep(0)
                await asyncio.sleep(0.25)
        except asyncio.CancelledError:
            return
        except Exception:
            return

    async def _stale_watchdog(self) -> None:
        try:
            period = float(os.getenv("ASTER_WATCHDOG_PERIOD_S", str(WATCHDOG_PERIOD_S)))
        except Exception:
            period = WATCHDOG_PERIOD_S
        try:
            while self._running:
                now = time.time()
                stale_cut = now - (STALE_MS / 1000.0)
                stale_syms = [s for s, ts in self._last_update.items() if ts < stale_cut]
                if stale_syms:
                    try:
                        await self._warmup_rest(stale_syms)
                    except Exception:
                        pass
                await asyncio.sleep(period)
        except asyncio.CancelledError:
            return
        except Exception:
            return

    async def connect(self):
        self._running = True
        if self.logger:
            self.logger("Aster: connecté")

    def book(self, sym: str) -> Optional[_Book]:
        return self._books.get((sym or "").upper())

    async def get_mid(self, symbol: str) -> Optional[float]:
        s = (symbol or "").upper()
        b = self.book(s)
        m = b.mid() if b else None
        if m is not None and m > 0:
            return float(m)
        await self._warmup_rest([s])
        b2 = self.book(s)
        return float(b2.mid()) if (b2 and b2.mid() is not None) else None

    def get_book(self, sym: str) -> Optional[Tuple[float, float, float]]:
        b = self._books.get((sym or "").upper())
        if not b or b.bid is None or b.ask is None:
            return None
        return float(b.bid), float(b.ask), float(b.t or time.time())

    def get_l2_book(self, sym: str) -> Optional[Dict[str, List[Tuple[float, float]]]]:
        return self._l2.get((sym or "").upper())

    @property
    def books(self) -> List[str]:
        return list(self._books.keys())

    async def start(self, symbols: List[str]):
        if not self._running:
            self._running = True
            if self.logger:
                self.logger("Aster: connecté")

        to_add = [s.upper() for s in (symbols or []) if s and s.upper() not in self._symbols]
        if to_add:
            await self._warmup_rest(to_add)
            self._symbols.extend(to_add)

        await self._restart_ws()

        if not self._poller_task or self._poller_task.done():
            self._poller_task = asyncio.create_task(self._rest_bookticker_poller())
        if not self._watchdog_task or self._watchdog_task.done():
            self._watchdog_task = asyncio.create_task(self._stale_watchdog())

    async def subscribe_orderbook(self, symbol: str):
        s = (symbol or "").upper()
        if not s:
            return

        if s not in self._symbols:
            await self._warmup_rest([s])
            self._symbols.append(s)
            if self.logger:
                self.logger(f"Aster abonnement carnet: {s}")
            await self._restart_ws()

        if not self._poller_task or self._poller_task.done():
            self._poller_task = asyncio.create_task(self._rest_bookticker_poller())
        if not self._watchdog_task or self._watchdog_task.done():
            self._watchdog_task = asyncio.create_task(self._stale_watchdog())

    async def stop(self):
        self._running = False
        if self._poller_task:
            self._poller_task.cancel()
            self._poller_task = None
        if self._watchdog_task:
            self._watchdog_task.cancel()
            self._watchdog_task = None
        for t in self._ws_tasks:
            t.cancel()
        self._ws_tasks.clear()

    async def get_fees(self) -> Dict[str, float]:
        return {"taker_bps": 3.5, "maker_bps": 1.0}

    async def get_futures_balance_usd(self) -> Optional[float]:
        if not self._is_futures or not self._api_key or not self._api_secret:
            return None
        base = "/fapi/v2/balance"
        ts = int(time.time() * 1000)
        data = await self._get(base, {"timestamp": str(ts), "recvWindow": "5000"})
        if data is None:
            data = await self._get("/fapi/v3/balance", {"timestamp": str(ts), "recvWindow": "5000"})
        if not isinstance(data, list):
            return None
        total = 0.0
        for row in data:
            try:
                asset = (row.get("asset") or "").upper()
                if asset in ("USDT", "USDC"):
                    v = row.get("balance")
                    if v is None:
                        v = row.get("walletBalance")
                    total += float(v or 0.0)
            except Exception:
                continue
        return total

    async def get_open_positions(self) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        if not (self._is_futures and self._api_key and self._api_secret):
            return out
        ts = int(time.time() * 1000)
        data = await self._get("/fapi/v2/positionRisk", {"timestamp": str(ts), "recvWindow": "5000"})
        if not isinstance(data, list):
            return out
        for row in data:
            try:
                sym = (row.get("symbol") or "").upper()
                amt = float(row.get("positionAmt") or 0.0)
                if sym and abs(amt) > 0:
                    out.append({"symbol": sym, "qty": amt})
            except Exception:
                continue
        return out

    async def place_order(
        self,
        symbol: str,
        side: str,
        qty: float | None = None,
        order_type: str = "MARKET",
        price: float | None = None,
        reduce_only: bool = False,
        quote_usd: float | None = None,
        client_id: str | None = None,
    ) -> dict:
        """
        Envoie un ordre réel à l'API perp d'Aster compatible Binance Futures:
          - MARKET avec 'quantity' ou 'quoteOrderQty' si quote_usd est fourni
          - LIMIT avec 'timeInForce' IOC si price est donné
          - Paramètre reduceOnly supporté en futures
        Retourne un dict {ok, venue, symbol, side, qty, raw, why?}
        """
        try:
            s = (symbol or "").upper()
            sd = "BUY" if str(side).upper() == "BUY" else "SELL"
            typ = "MARKET" if str(order_type or "MARKET").upper() == "MARKET" else "LIMIT"
            path = "/fapi/v1/order" if self._is_futures else "/api/v3/order"
            ts = int(time.time() * 1000)
            p: dict[str, str] = {
                "symbol": s,
                "side": sd,
                "type": typ,
                "timestamp": str(ts),
                "recvWindow": "5000",
            }
            if client_id:
                p["newClientOrderId"] = client_id[:36]
            if typ == "MARKET":
                if quote_usd is not None:
                    p["quoteOrderQty"] = f"{float(quote_usd):.8f}"
                elif qty is not None:
                    p["quantity"] = f"{float(qty):.8f}"
                # reduceOnly uniquement côté futures
                if self._is_futures:
                    p["reduceOnly"] = "true" if bool(reduce_only) else "false"
            else:
                # LIMIT
                if qty is not None:
                    p["quantity"] = f"{float(qty):.8f}"
                if price is not None:
                    p["price"] = f"{float(price):.8f}"
                p["timeInForce"] = "IOC"
                if self._is_futures:
                    p["reduceOnly"] = "true" if bool(reduce_only) else "false"

            raw = await self._post(path, p)
            ok = False
            why = None

            # Déterminer ok et qty exécutée
            filled_qty = 0.0
            avg_price = 0.0
            if isinstance(raw, dict):
                status = str(raw.get("status") or raw.get("orderStatus") or "").upper()
                # Binance futures renvoie 'FILLED' ou 'PARTIALLY_FILLED'
                if status in ("FILLED", "PARTIALLY_FILLED", "NEW", "PENDING_NEW"):
                    ok = True
                # Parse exécution
                ex = raw.get("executedQty") or raw.get("executed_qty") or raw.get("cumBase") or raw.get("cumBaseQty")
                if ex is None and isinstance(raw.get("fills"), list):
                    try:
                        ex = sum(float(f.get("qty") or f.get("executedQty") or 0.0) for f in raw["fills"])
                        if not avg_price and ex:
                            num = sum(float((f.get("price") or 0.0)) * float((f.get("qty") or 0.0)) for f in raw["fills"])
                            avg_price = (num / float(ex)) if ex else 0.0
                    except Exception:
                        pass
                if ex is None:
                    cq = raw.get("cummulativeQuoteQty") or raw.get("cumQuote") or raw.get("cumQuoteQty")
                    try:
                        ppx = float(raw.get("avgPrice") or raw.get("avg_price") or raw.get("price") or 0.0)
                    except Exception:
                        ppx = 0.0
                    if cq and ppx > 0:
                        try:
                            ex = float(cq) / float(ppx)
                        except Exception:
                            ex = None
                try:
                    filled_qty = float(ex or 0.0)
                except Exception:
                    filled_qty = float(qty or 0.0)
                try:
                    avg_price = float(raw.get("avgPrice") or raw.get("avg_price") or raw.get("price") or avg_price or 0.0)
                except Exception:
                    pass
                err_msg = raw.get("msg") or raw.get("message") or raw.get("code")
                if isinstance(err_msg, (int, float)):
                    err_msg = str(err_msg)
                why = err_msg

            # Log d'audit des bruts
            try:
                trunc = str(raw)
                if len(trunc) > 500:
                    trunc = trunc[:500] + "...[trunc]"
                print(f"[AS RAW] sym={s} side={sd} req_qty={float(qty or 0.0):.8f} quote_usd={float(quote_usd or 0.0):.2f} raw={trunc}")
            except Exception:
                pass

            return {
                "ok": bool(ok),
                "venue": "ASTER",
                "symbol": s,
                "side": sd,
                "qty": float(filled_qty if filled_qty > 0 else float(qty or 0.0)),
                "avg_price": float(avg_price),
                "raw": raw,
                "why": why,
            }
        except Exception as e:
            try:
                print(f"[AS RAW] sym={symbol} except={e!r}")
            except Exception:
                pass
            return {"ok": False, "venue": "ASTER", "symbol": symbol, "side": side, "qty": float(qty or 0.0), "why": str(e)}

    async def flatten_best_effort(self, symbols: Optional[List[str]] = None) -> Dict[str, Any]:
        res: Dict[str, Any] = {"ok": True, "details": []}
        try:
            try:
                retry_ms = float(self.creds.get("flatten_retry_ms", 800))
            except Exception:
                retry_ms = 800.0
            try:
                timeout_s = float(self.creds.get("flatten_timeout_s", 10.0))
            except Exception:
                timeout_s = 10.0

            deadline = time.time() + timeout_s
            want = {s.upper() for s in (symbols or [])} if symbols else None

            while time.time() < deadline:
                pos = await self.get_open_positions()
                if not pos:
                    break
                any_action = False
                for p in pos:
                    sym = (p.get("symbol") or "").upper()
                    if not sym:
                        continue
                    if want and sym not in want:
                        continue
                    qty = float(p.get("qty") or 0.0)
                    if qty == 0.0:
                        continue
                    side = "SELL" if qty > 0 else "BUY"
                    r = await self.place_order(
                        sym, side, qty=abs(qty), order_type="MARKET",
                        price=None, reduce_only=True, quote_usd=None,
                        client_id=f"ro{int(time.time()*1000):x}"[:24]
                    )
                    res["details"].append({sym: r})
                    if not r.get("ok", False):
                        res["ok"] = False
                    any_action = True
                if not any_action:
                    break
                await asyncio.sleep(retry_ms / 1000.0)

            pos_end = await self.get_open_positions()
            if pos_end:
                res["ok"] = False
            return res
        except Exception as e:
            return {"ok": False, "why": f"flatten_exception:{e!r}"}
