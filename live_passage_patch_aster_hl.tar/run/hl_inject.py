
# run/hl_inject.py
import os
import sys
import inspect
from typing import Tuple, Any, Callable, Dict, List
from eth_account import Account

def _env(name: str) -> str:
    v = os.environ.get(name)
    if not v or not v.strip():
        raise RuntimeError(f"Variable d'environnement manquante: {name}")
    return v.strip()

def _import_official_hl():
    import importlib
    mod = sys.modules.get("hyperliquid")
    if mod is not None:
        mod_file = getattr(mod, "__file__", "") or ""
        if mod_file.endswith("hyperliquid.py") and not hasattr(mod, "__path__"):
            del sys.modules["hyperliquid"]

    site_paths = [p for p in list(sys.path) if "site-packages" in p.lower()]
    other_paths = [p for p in list(sys.path) if p not in site_paths]
    if site_paths:
        sys.path[:] = site_paths + other_paths

    hl_exchange = importlib.import_module("hyperliquid.exchange")
    hl_constants = importlib.import_module("hyperliquid.utils.constants")

    Exchange = getattr(hl_exchange, "Exchange")
    MAINNET_URL = getattr(hl_constants, "MAINNET_API_URL", "https://api.hyperliquid.xyz")
    return Exchange, hl_constants, MAINNET_URL

def _mk_wrapper(ex: Any, fn_name: str) -> Callable:
    """
    Wrap des méthodes SDK pour normaliser les appels et éviter les doublons de paramètres.
    Adapte les noms réels: instrument 'name', prix 'limit_px', type 'order_type', etc.
    """
    orig = getattr(ex, fn_name)
    sig = inspect.signature(orig)
    params = list(sig.parameters.keys())

    # Noms de paramètres acceptés par le SDK
    qty_keys  = [k for k in ("sz", "size", "quantity", "qty") if k in params]
    coin_keys = [k for k in ("name", "coin", "symbol", "asset") if k in params]
    side_keys = [k for k in ("is_buy", "isBuy", "side") if k in params]
    px_keys   = [k for k in ("limit_px", "px", "price") if k in params]
    opts_keys = [k for k in ("order_type", "opts", "order", "options", "orderFlags") if k in params]
    slip_keys = [k for k in ("slippage", "slip") if k in params]

    if not coin_keys or not side_keys or not qty_keys:
        setattr(ex, "_api_ok", False)
        return orig

    qk = qty_keys[0]
    ck = coin_keys[0]
    sk = side_keys[0]
    pk = px_keys[0] if px_keys else None
    ok = opts_keys[0] if opts_keys else None
    lk = slip_keys[0] if slip_keys else None

    # Pour gérer proprement "multiple values for argument 'X'"
    dup_whitelist = {
        qk, ck, sk
    } | set(["sz","size","quantity","qty","name","coin","symbol","asset"])       | set(filter(None, [pk])) | {"px","price","limit_px"}       | set(filter(None, [ok])) | {"order_type","opts","order","options","orderFlags"}       | set(filter(None, [lk])) | {"slippage","slip"}

    def _wrapped(*args, **kwargs):
        try:
            bound = sig.bind_partial(*args, **kwargs)
        except TypeError as e:
            msg = str(e)
            lowered = msg.lower()
            popped = False
            for k in dup_whitelist:
                if k and f"multiple values for argument '{k.lower()}'" in lowered:
                    if k in kwargs:
                        kwargs.pop(k, None)
                        popped = True
                        break
            if popped:
                bound = sig.bind_partial(*args, **kwargs)
            else:
                raise

        coin = bound.arguments.get(ck, kwargs.get(ck))
        side = bound.arguments.get(sk, kwargs.get(sk))
        qty  = bound.arguments.get(qk, kwargs.get(qk))
        px   = bound.arguments.get(pk, kwargs.get(pk)) if pk else None
        opts = bound.arguments.get(ok, kwargs.get(ok)) if ok else None
        slp  = bound.arguments.get(lk, kwargs.get(lk)) if lk else None

        clean = {ck: coin, sk: side, qk: float(qty) if qty is not None else qty}
        if pk and px is not None:
            clean[pk] = float(px)
        if ok and opts is not None:
            clean[ok] = opts
        if lk and slp is not None:
            clean[lk] = float(slp)

        return orig(**clean)

    return _wrapped

def _construct_exchange(Exchange, MAINNET_URL: str, acct: Any, addr: str, priv: str):
    tried: List[str] = []
    ex = None
    ok_kwargs: Dict[str, Any] | None = None

    try:
        sig_init = inspect.signature(Exchange.__init__)
    except Exception:
        sig_init = inspect.signature(Exchange)

    params = set(k for k in sig_init.parameters.keys() if k != "self")

    base_names = [n for n in ("base_url", "baseUrl", "url", "rest_url", "api_url") if n in params]
    acct_names_obj = [n for n in ("account", "wallet") if n in params]
    addr_names = [n for n in ("account_address", "accountAddress", "address") if n in params]
    key_names = [n for n in ("private_key", "priv_key", "key") if n in params]

    candidates: List[Dict[str, Any]] = []

    for b in base_names or [None]:
        for a in acct_names_obj:
            kw = {}
            if b:
                kw[b] = MAINNET_URL
            kw[a] = acct
            candidates.append(kw)

    for b in base_names or [None]:
        for a in addr_names:
            kw = {}
            if b:
                kw[b] = MAINNET_URL
            kw[a] = addr
            candidates.append(kw)

    for b in base_names or [None]:
        for k in key_names:
            kw = {}
            if b:
                kw[b] = MAINNET_URL
            kw[k] = priv
            candidates.append(kw)

    if base_names:
        for b in base_names:
            candidates.append({b: MAINNET_URL})

    candidates.append({})

    pos_trials = [(), (MAINNET_URL,)]

    for kw in candidates:
        try:
            tried.append(f"kwargs={list(kw.keys())}")
            ex = Exchange(**kw)  # type: ignore
            ok_kwargs = kw
            break
        except TypeError as e:
            tried.append(f"fail:{e}")
        except Exception as e:
            tried.append(f"fail:{e}")

    if ex is None:
        for pos in pos_trials:
            try:
                tried.append(f"positional={len(pos)}")
                ex = Exchange(*pos)  # type: ignore
                ok_kwargs = {"<positional>": pos}
                break
            except TypeError as e:
                tried.append(f"fail_pos:{e}")
            except Exception as e:
                tried.append(f"fail_pos:{e}")

    if ex is None:
        info = " | ".join(tried[-6:])
        raise RuntimeError(f"Exchange init failed. Tries: {info}")

    try:
        print(f"[HL INIT OK] using {ok_kwargs}")
    except Exception:
        pass

    return ex

def _ping_info(info) -> None:
    try:
        _ = getattr(info, "user", None)
    except Exception:
        pass

def build_exchange_and_wallet() -> Tuple[Any, str]:
    Exchange, constants, MAINNET_URL = _import_official_hl()

    priv = _env("HL_PRIVATE_KEY")
    acct = Account.from_key(priv)
    addr = acct.address

    ex = _construct_exchange(Exchange, MAINNET_URL, acct, addr, priv)

    if not hasattr(ex, "_client_creds"):
        ex._client_creds = {}
    try:
        ex._client_creds["min_trade_usd"] = 10.0
    except Exception:
        pass

    try:
        sig_mo = str(inspect.signature(getattr(ex, "market_open")))
    except Exception as e:
        sig_mo = f"error:{e!r}"
    try:
        sig_or = str(inspect.signature(getattr(ex, "order")))
    except Exception as e:
        sig_or = f"error:{e!r}"

    setattr(ex, "_api_ok", True)
    try:
        if hasattr(ex, "market_open"):
            ex.market_open = _mk_wrapper(ex, "market_open")  # type: ignore
        else:
            setattr(ex, "_api_ok", False)
        if hasattr(ex, "order"):
            ex.order = _mk_wrapper(ex, "order")  # type: ignore
        else:
            setattr(ex, "_api_ok", False)
    except Exception:
        setattr(ex, "_api_ok", False)

    api_ok = bool(getattr(ex, "_api_ok", True))
    tag = "OK" if api_ok else "MISMATCH"
    print(f"[HL API {tag}] market_open={sig_mo} order={sig_or}")

    _ping_info(getattr(ex, "info", None))
    return ex, addr

def quick_test() -> None:
    ex, addr = build_exchange_and_wallet()
    print("Exchange OK pour", addr)
